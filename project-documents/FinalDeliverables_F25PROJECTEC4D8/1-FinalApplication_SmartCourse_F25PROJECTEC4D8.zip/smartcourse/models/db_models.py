from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func

from ..extensions import db
from ..utils import sanitize_for_json


class SearchSession(db.Model):
    __tablename__ = "search_sessions"

    id: int = db.Column(db.Integer, primary_key=True)
    query_text: str = db.Column(db.Text, nullable=False)
    tfidf_results: Any = db.Column(db.JSON, nullable=True)
    neural_results: Any = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, server_default=func.now())

    saved_recommendations = db.relationship(
        "SavedRecommendation",
        back_populates="session",
        cascade="all, delete-orphan",
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "query_text": self.query_text,
            "tfidf_results": sanitize_for_json(self.tfidf_results) if self.tfidf_results else [],
            "neural_results": sanitize_for_json(self.neural_results) if self.neural_results else [],
            "created_at": self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at,
            "saved_recommendations": [rec.to_dict() for rec in self.saved_recommendations],
        }


class SavedRecommendation(db.Model):
    __tablename__ = "saved_recommendations"

    id: int = db.Column(db.Integer, primary_key=True)
    session_id: int = db.Column(db.Integer, db.ForeignKey("search_sessions.id"), nullable=False, index=True)
    model_type: str = db.Column(db.String(32), nullable=False)
    course_id: str | None = db.Column(db.String(128), nullable=True)
    course_title: str = db.Column(db.Text, nullable=False)
    department: str | None = db.Column(db.String(128))
    course_payload: Any = db.Column(db.JSON, nullable=True)
    relevance_score: float | None = db.Column(db.Float)
    saved_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    session = db.relationship("SearchSession", back_populates="saved_recommendations")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "model_type": self.model_type,
            "course_id": self.course_id,
            "course_title": self.course_title,
            "department": self.department,
            "metadata": sanitize_for_json(self.course_payload) if self.course_payload else None,
            "relevance_score": self.relevance_score,
            "saved_at": self.saved_at.isoformat() if isinstance(self.saved_at, datetime) else self.saved_at,
        }
