from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ..data.preprocess import normalize_text


@dataclass(slots=True)
class TFIDFConfig:
    ngram_range: tuple[int, int] = (1, 2)
    min_df: int = 2
    max_df: float = 0.9
    text_column: str = "processed_description"
    spacy_model: str = "en_core_web_sm"


class TFIDFRecommender:
    def __init__(self, config: TFIDFConfig | None = None, vectorizer: TfidfVectorizer | None = None):
        self.config = config or TFIDFConfig()
        self.vectorizer = vectorizer or TfidfVectorizer(
            ngram_range=self.config.ngram_range,
            min_df=self.config.min_df,
            max_df=self.config.max_df,
        )
        self.tfidf_matrix = None
        self.dataset: pd.DataFrame | None = None

    def fit(self, dataset: pd.DataFrame) -> "TFIDFRecommender":
        if self.config.text_column not in dataset.columns:
            raise KeyError(f"Expected column '{self.config.text_column}' in dataset")

        self.dataset = dataset.reset_index(drop=True)
        texts = self.dataset[self.config.text_column].fillna("")
        self.tfidf_matrix = self.vectorizer.fit_transform(texts)
        return self

    def recommend(self, query: str, top_n: int = 10) -> list[dict[str, Any]]:
        if self.tfidf_matrix is None or self.dataset is None:
            raise RuntimeError("TF-IDF model is not fitted. Call fit() before recommend().")

        processed_query = normalize_text(query, model_name=self.config.spacy_model)
        if not processed_query:
            return []
        query_vector = self.vectorizer.transform([processed_query])
        scores = cosine_similarity(query_vector, self.tfidf_matrix).flatten()

        if np.all(scores == 0):
            return []

        top_indices = np.argsort(scores)[::-1][:top_n]
        return self._build_results(top_indices, scores[top_indices])

    def save(self, path: str) -> None:
        if self.tfidf_matrix is None or self.dataset is None:
            raise RuntimeError("Cannot save TF-IDF model before fitting")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = {
            "config": self.config,
            "vectorizer": self.vectorizer,
            "matrix": self.tfidf_matrix,
            "dataset": self.dataset,
        }
        joblib.dump(payload, path)

    @classmethod
    def load(cls, path: str) -> "TFIDFRecommender":
        payload = joblib.load(path)
        obj = cls(config=payload.get("config"), vectorizer=payload.get("vectorizer"))
        obj.tfidf_matrix = payload.get("matrix")
        obj.dataset = payload.get("dataset")
        return obj

    def _build_results(self, indices: np.ndarray, scores: np.ndarray) -> list[dict[str, Any]]:
        if self.dataset is None:
            return []
        results = []
        for idx, score in zip(indices, scores):
            record = self.dataset.iloc[int(idx)].to_dict()
            record.update({
                "score": float(score),
                "model_type": "tfidf",
            })
            results.append(record)
        return results
