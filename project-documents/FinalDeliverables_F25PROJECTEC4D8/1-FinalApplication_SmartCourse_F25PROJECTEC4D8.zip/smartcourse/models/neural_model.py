from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass(slots=True)
class NeuralConfig:
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    text_column: str = "recommendation_text"
    show_progress_bar: bool = True


class NeuralRecommender:
    def __init__(self, config: NeuralConfig | None = None, model: SentenceTransformer | None = None):
        self.config = config or NeuralConfig()
        self.model = model or SentenceTransformer(self.config.model_name)
        self.embeddings: np.ndarray | None = None
        self.dataset: pd.DataFrame | None = None

    def fit(self, dataset: pd.DataFrame) -> "NeuralRecommender":
        if self.config.text_column not in dataset.columns:
            raise KeyError(f"Expected column '{self.config.text_column}' in dataset")

        self.dataset = dataset.reset_index(drop=True)
        corpus = self.dataset[self.config.text_column].fillna("").tolist()
        self.embeddings = self.model.encode(
            corpus,
            show_progress_bar=self.config.show_progress_bar,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return self

    def recommend(self, query: str, top_n: int = 10) -> list[dict[str, Any]]:
        if self.embeddings is None or self.dataset is None:
            raise RuntimeError("Neural model is not fitted. Call fit() before recommend().")

        query_embedding = self.model.encode(
            [query],
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        scores = cosine_similarity(query_embedding, self.embeddings)[0]
        if np.all(scores == 0):
            return []
        top_indices = np.argsort(scores)[::-1][:top_n]
        return self._build_results(top_indices, scores[top_indices])

    def save(self, path: str) -> None:
        if self.embeddings is None or self.dataset is None:
            raise RuntimeError("Cannot save neural embeddings before fitting")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = {
            "config": self.config,
            "embeddings": self.embeddings,
            "dataset": self.dataset,
        }
        joblib.dump(payload, path)

    @classmethod
    def load(cls, path: str, model: SentenceTransformer | None = None) -> "NeuralRecommender":
        payload = joblib.load(path)
        config = payload.get("config", NeuralConfig())
        obj = cls(config=config, model=model or SentenceTransformer(config.model_name))
        obj.embeddings = payload.get("embeddings")
        obj.dataset = payload.get("dataset")
        return obj

    def _build_results(self, indices: np.ndarray, scores: np.ndarray) -> list[dict[str, Any]]:
        if self.dataset is None:
            return []
        results = []
        for idx, score in zip(indices, scores):
            record = self.dataset.iloc[int(idx)].to_dict()
            record.update(
                {
                    "score": float(score),
                    "model_type": "neural",
                }
            )
            results.append(record)
        return results
