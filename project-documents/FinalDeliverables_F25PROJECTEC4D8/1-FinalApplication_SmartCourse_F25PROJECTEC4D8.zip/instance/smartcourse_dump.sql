BEGIN TRANSACTION;
CREATE TABLE saved_recommendations (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	model_type VARCHAR(32) NOT NULL, 
	course_id VARCHAR(128), 
	course_title TEXT NOT NULL, 
	department VARCHAR(128), 
	course_payload JSON, 
	relevance_score FLOAT, 
	saved_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES search_sessions (id)
);
CREATE TABLE search_sessions (
	id INTEGER NOT NULL, 
	query_text TEXT NOT NULL, 
	tfidf_results JSON, 
	neural_results JSON, 
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_saved_recommendations_session_id ON saved_recommendations (session_id);
COMMIT;
